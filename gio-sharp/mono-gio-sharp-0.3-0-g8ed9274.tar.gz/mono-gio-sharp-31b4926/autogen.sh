#!/bin/sh

echo "error: run either autogen-2.18.sh or autogen-2.22.sh"

exit 1;
