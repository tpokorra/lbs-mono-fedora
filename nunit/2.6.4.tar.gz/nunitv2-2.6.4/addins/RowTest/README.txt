= RowTest Extension for NUnit


== Installing

Install the RowTest Extension by copying the files NUnitExtension.RowTest and
NUnitExtension.RowTest.AddIn to the NUnit Addin directory (e.g.
C:\Program Files\NUnit 2.4.2\bin\addins). When you start NUnit you, click
Tools > Addins... You should see the line "Row Test Extension" under Addin.


== Usage

In order to use the extension reference the assembly NUnitExtension.RowTest in
your unit test project. See the sample project for further information.


== License

RowTest Extension for NUnit is released under the MIT license.


== Homepage

http://www.andreas-schlapsi.com/projects/rowtest
