﻿// ****************************************************************
// Copyright 2012, Charlie Poole
// This is free software licensed under the NUnit license. You may
// obtain a copy of the license at http://nunit.org
// ****************************************************************

namespace NUnit.Util
{
    public enum TestLabelLevel
    {
        Off = 0,
        On = 1,
        All = 2,
    }
}
