﻿namespace Demo.data
{
    class Basic { }
}
