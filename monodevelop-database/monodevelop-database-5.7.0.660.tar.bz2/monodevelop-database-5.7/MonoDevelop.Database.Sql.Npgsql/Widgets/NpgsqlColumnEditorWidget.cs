
using System;

namespace MonoDevelop.Database.Sql.Npgsql
{
	
	
	[System.ComponentModel.Category("MonoDevelop.Database.Sql.Npgsql")]
	[System.ComponentModel.ToolboxItem(true)]
	public partial class NpgsqlColumnEditorWidget : Gtk.Bin
	{
		
		public NpgsqlColumnEditorWidget()
		{
			this.Build();
		}
	}
}
