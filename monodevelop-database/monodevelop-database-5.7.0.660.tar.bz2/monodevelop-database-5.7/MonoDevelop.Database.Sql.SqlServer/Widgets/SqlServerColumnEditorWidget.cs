
using System;

namespace MonoDevelop.Database.Sql.SqlServer
{
	
	
	[System.ComponentModel.Category("MonoDevelop.Database.Sql.SqlServer")]
	[System.ComponentModel.ToolboxItem(true)]
	public partial class SqlServerColumnEditorWidget : Gtk.Bin
	{
		
		public SqlServerColumnEditorWidget()
		{
			this.Build();
		}
	}
}
