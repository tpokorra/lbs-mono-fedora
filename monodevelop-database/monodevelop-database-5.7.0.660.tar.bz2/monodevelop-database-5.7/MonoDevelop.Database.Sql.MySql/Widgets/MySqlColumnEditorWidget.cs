
using System;

namespace MonoDevelop.Database.Sql.MySql
{
	
	
	[System.ComponentModel.Category("MonoDevelop.Database.Sql.MySql")]
	[System.ComponentModel.ToolboxItem(true)]
	public partial class MySqlColumnEditorWidget : Gtk.Bin
	{
		
		public MySqlColumnEditorWidget()
		{
			this.Build();
		}
	}
}
