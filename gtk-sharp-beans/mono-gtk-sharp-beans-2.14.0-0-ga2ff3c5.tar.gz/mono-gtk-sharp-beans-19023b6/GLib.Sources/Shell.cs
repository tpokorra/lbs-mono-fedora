// GLib.Shell.cs
//
// Author(s):
//      Stephane Delcroix <stephane@delcroix.org>
//
// Copyright (c) 2009 Novell, Inc.
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of version 2 of the Lesser GNU General 
// Public License as published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this program; if not, write to the
// Free Software Foundation, Inc., 59 Temple Place - Suite 330,
// Boston, MA 02111-1307, USA.


using System;
using System.Runtime.InteropServices;

namespace GLib
{
	public class Shell
	{
		[DllImport ("libglib-2.0-0.dll")]
		static extern IntPtr g_shell_quote (IntPtr unquoted_string);

		public static string Quote (string unquoted)
		{
			IntPtr native_string = GLib.Marshaller.StringToPtrGStrdup (unquoted);
			string quoted = GLib.Marshaller.PtrToStringGFree (g_shell_quote (native_string));
			GLib.Marshaller.Free (native_string);
			return quoted;
		}
	}
}
