#!/bin/bash

. vars.sh

sudo rm -r $SOCKDIR $SHIMDIR $CONFIGDIR $WEBDIR
