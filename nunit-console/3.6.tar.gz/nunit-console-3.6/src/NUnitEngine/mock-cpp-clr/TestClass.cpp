#include "TestClass.h"

void TestClass::TestMethod()
{
    Assert::AreEqual(42, _theMeaningOfLife);
}
